﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Assignment3.Data;
using Assignment3.Models;

namespace Assignment3.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ImmunizationsController : ControllerBase
    {
        private readonly Assignment3Context _context;

        public ImmunizationsController(Assignment3Context context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<Immunization>> post(Immunization immunization)
        {
            try
            {
                Immunization immunizationData = new Immunization();

                immunizationData.Id = Guid.NewGuid();
                immunizationData.CreationTime = DateTime.Now;
                immunizationData.OfficialName = immunization.OfficialName;
                immunizationData.TradeName = immunization.TradeName;
                immunizationData.LotNumber = immunization.LotNumber;
                immunizationData.ExpirationDate = DateTime.Now;
                immunizationData.UpdatedTime = DateTime.Now;


                await _context.Immunization.AddAsync(immunizationData);
                await _context.SaveChangesAsync();
                return Ok(immunizationData);

            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Immunization>> Get(Guid id)
        {
            try
            {
                var result = _context.Immunization.Where(a => a.Id == id).FirstOrDefault();
                if (result == null)
                {
                    return NoContent();
                }
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Immunization>> Put(Guid id, Immunization immunization)
        {
            try
            {
                var result = _context.Immunization.Where(a => a.Id == id).FirstOrDefault();
                if (result == null)
                {
                    return NoContent();
                }

                result.OfficialName = immunization.OfficialName;
                result.TradeName = immunization.TradeName;
                result.LotNumber = immunization.LotNumber;
                result.ExpirationDate = immunization.ExpirationDate;
                result.UpdatedTime = immunization.UpdatedTime;

                _context.Immunization.Update(result);
                await _context.SaveChangesAsync();

                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<ActionResult<Immunization>> GetQuery([FromQuery] DateTimeOffset? creationTime, [FromQuery] string? officialName, [FromQuery] string? tradeName, [FromQuery] string? lotNumber)
        {
            try
            {
                List<Immunization> result = new List<Immunization>();
                if (creationTime != null)
                {
                    result = _context.Immunization.Where(a => a.CreationTime == creationTime).ToList();
                }
                else if (officialName != null)
                {
                    result = _context.Immunization.Where(a => a.OfficialName == officialName).ToList();
                }
                else if (tradeName != null)
                {
                    result = _context.Immunization.Where(a => a.TradeName == tradeName).ToList();
                }
                else if (lotNumber != null)
                {
                    result = _context.Immunization.Where(a => a.LotNumber == lotNumber).ToList();
                }
                if (result.Count == 0)
                {
                    return NoContent();
                }
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Immunization>> Delete(Guid id)
        {
            try
            {
                var immunization = new Immunization()
                {
                    Id = id
                };
                _context.Immunization.Remove(immunization);
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500);
            }
        }




    }
}
